/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.if2000_introduccion_progra;

/**
 *
 * @author mayco
 */
import domain.Binnacle;
import domain.Person;
import domain.SavingAccount;
import java.util.Scanner;

public class IF2000_Lab3 {
    public static void main(String[] args) {
        // TODO code application logic here
        
        Person client1 = 
        new Person("Edgardo", "Corrales", "1-2323-4545", 18, "45456789");
        
        SavingAccount account1 = 
        new SavingAccount("2025-09-04", 12, 5, "1000567801", 25000, client1);
        
        
        
        account1.deposit(3000);
        
        
        Binnacle bin = new Binnacle("withdraw", account1, 200);
        System.out.println(bin.toString());
        
        /*
        System.out.println(account1.toString());
        
        System.out.println("\n\n\n--------------------------------------------");
        System.out.println("Withdraw of money");
        System.out.println("--------------------------------------------\n\n");
        
        account1.withdraw(16000);
        
        System.out.println(account1.toString());
*/
    }
}
